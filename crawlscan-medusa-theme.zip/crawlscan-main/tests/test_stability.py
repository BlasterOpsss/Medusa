"""Stability under load: SQLite (WAL, busy_timeout, shared lock), 503 busy (queue, memory), history cap
Pons, _SCAN limit by transfers, paginated getLogs, bot and site on busy. No network."""
import io, json, os, sqlite3, tempfile, threading, time, unittest, urllib.error, urllib.request
from unittest import mock
from http.server import ThreadingHTTPServer

import fakes
from fakes import ch
import alerts_recheck as ar
import db
import engine
import memguard
import server
import test_alerts_recheck as tar
from alerts_store import AlertsStore
from recent_store import RecentStore
from rewards_store import RewardsStore
from bot import api as bot_api, text as T
from test_bot import FakeAPI, make, private, drain, RH


class TestSqlite(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "d.db")
        self.stores = [RecentStore(self.path), AlertsStore(self.path), RewardsStore(self.path)]

    def tearDown(self):
        for s in self.stores:
            s.close()
        self.tmp.cleanup()

    def test_wal_timeout_shared_lock(self):
        rs, al, rw = self.stores
        self.assertEqual(rs.db.execute("PRAGMA journal_mode").fetchone()[0], "wal")
        self.assertEqual(al.db.execute("PRAGMA busy_timeout").fetchone()[0], 5000)
        self.assertIs(rs._lock, al._lock)
        self.assertIs(al._lock, rw._lock)

    def test_concurrent_writers_no_lock_errors(self):
        rs, al, rw = self.stores
        errors = []

        def run(fn):
            try:
                for i in range(60):
                    fn(i)
            except Exception as e:
                errors.append(e)

        res = lambda i: {"token": f"0x{i:040x}", "band": "SAFE", "score": 80, "header": {"ticker": "T"}}
        jobs = [lambda i: rs.record(res(i)),
                lambda i: al.watch(i, f"0x{i:040x}", "robinhood", now=int(time.time())),
                lambda i: rw.set_meta(f"k{i}", {"v": i})]
        ts = [threading.Thread(target=run, args=(f,)) for f in jobs for _ in range(2)]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
        self.assertEqual(errors, [])
        self.assertEqual(len(rs.recent(50)), 50)

    def test_other_process_writer_waits_not_fails(self):
        """Another connection holds a write for 0.5 s: the store waits (busy_timeout) instead of failing with database is locked."""
        other = sqlite3.connect(self.path, isolation_level=None, check_same_thread=False)
        other.execute("BEGIN IMMEDIATE")
        threading.Timer(0.5, lambda: other.execute("COMMIT")).start()
        t0 = time.time()
        self.stores[0].record({"token": "0x" + "1" * 40, "band": "SAFE", "score": 1})
        self.assertGreaterEqual(time.time() - t0, 0.4)
        other.close()


class TestScanCache(unittest.TestCase):

    def setUp(self):
        self.p = [mock.patch.dict(ch._SCAN, clear=True), mock.patch.object(ch, "SCAN_CACHE_MAX_TRANSFERS", 10)]
        for p in self.p:
            p.start()

    def tearDown(self):
        for p in reversed(self.p):
            p.stop()

    def test_lru_by_transfers(self):
        launch = {"block": 1}
        for t in ("a", "b", "c"):
            ch.remember_scan(t, launch, [{}] * 4, 1)
        self.assertEqual(list(ch._SCAN), ["b", "c"])          # 12 > 10: the oldest is evicted
        ch.remember_scan("b", launch, [{}] * 4, 1)            # repeat — moves to the end
        ch.remember_scan("d", launch, [{}] * 4, 1)
        self.assertEqual(list(ch._SCAN), ["b", "d"])

    def test_too_large_not_stored(self):
        ch.remember_scan("a", {"block": 1}, [{}] * 3, 1)
        ch.remember_scan("big", {"block": 1}, [{}] * 11, 1)
        self.assertEqual(list(ch._SCAN), ["a"])
        self.assertIsNone(ch.scan_history("big"))

    def test_expired_dropped_and_drop_caches(self):
        with mock.patch.object(ch.time, "time", return_value=1000.0):
            ch.remember_scan("old", {"block": 1}, [{}], 1)
        ch.remember_scan("new", {"block": 1}, [{}], 1)
        self.assertEqual(list(ch._SCAN), ["new"])
        ch.drop_caches()
        self.assertEqual(ch._SCAN, {})


def _log(block, i=0):
    topic = lambda a: "0x" + "0" * 24 + a[2:]
    return {"address": fakes.TOKEN, "topics": [ch.TRANSFER_TOPIC, topic(fakes.CURVE), topic(fakes.WALLETS[block % 3])],
            "data": hex(10 + block), "transactionHash": f"0x{block:064x}", "blockNumber": hex(block), "logIndex": hex(i)}


class TestPagedLogs(unittest.TestCase):
    """getLogs in windows: one log per block 0..19, RPC truncates the response at LOG_CAP = 4 (like a public RPC)."""

    def setUp(self):
        self.calls = []

        def rpc(method, params):
            flt = params[0]
            lo, hi = int(flt["fromBlock"], 16), int(flt["toBlock"], 16)
            self.calls.append((lo, hi))
            return [_log(b) for b in range(lo, min(hi, 19) + 1)][:4]

        self.p = [mock.patch.object(ch, "rpc", side_effect=rpc), mock.patch.object(ch, "LOG_CAP", 4),
                  mock.patch.object(ch, "block_number", return_value=19)]
        for p in self.p:
            p.start()

    def tearDown(self):
        for p in reversed(self.p):
            p.stop()

    def test_pages_in_order_complete(self):
        pages = list(ch.iter_logs(0, 19))
        self.assertTrue(all(len(p) < 4 for p in pages))
        self.assertEqual([int(lg["blockNumber"], 16) for p in pages for lg in p], list(range(20)))
        self.assertEqual(len(ch.get_logs(0, 19)), 20)
        trs = ch.get_token_transfers(fakes.TOKEN, 0)
        self.assertEqual([t["block"] for t in trs], list(range(20)))
        self.assertIs(trs[0]["frm"], trs[1]["frm"])              # address — one string for the whole history

    def test_cap_stops_reading(self):
        list(ch.iter_logs(0, 19))
        full = len(self.calls)
        self.calls.clear()
        with ch._log_cap(5), self.assertRaises(ch.HistoryTooLarge):
            ch.get_token_transfers(fakes.TOKEN, 0)
        self.assertLess(len(self.calls), full)                  # nothing read past the cap
        self.assertEqual(len(ch.get_token_transfers(fakes.TOKEN, 0)), 20)   # cap applies only inside _log_cap


class TestHistoryCap(unittest.TestCase):

    def test_engine_too_large(self):
        with fakes.patched(), mock.patch.object(ch, "SCAN_MAX_LOGS", 5):
            with self.assertRaises(engine.ScanError) as cm:
                engine.scan(fakes.TOKEN)
        self.assertEqual(str(cm.exception), "token history too large")

    def test_under_cap_same(self):
        with fakes.patched():
            a = engine.scan(fakes.TOKEN)
        with fakes.patched(), mock.patch.object(ch, "SCAN_MAX_LOGS", len(fakes.transfers())):
            b = engine.scan(fakes.TOKEN)
        self.assertEqual((a["score"], a["band"]), (b["score"], b["band"]))


class TestMemguard(unittest.TestCase):

    def setUp(self):
        memguard._state.update(relieved=0.0, pause=memguard.RELIEVE_EVERY)
        self.env = mock.patch.dict(os.environ, {"MEMORY_SOFT_LIMIT_MB": "", "MEMORY_HARD_LIMIT_MB": ""})
        self.env.__enter__()
        self.out = io.StringIO()
        self.stdout = mock.patch("sys.stdout", self.out)
        self.stdout.__enter__()

    def tearDown(self):
        self.stdout.__exit__(None, None, None)
        self.env.__exit__(None, None, None)

    def test_limits_from_container(self):
        with mock.patch.object(memguard, "cgroup_limit_mb", return_value=None):      # cgroup not readable
            self.assertEqual(memguard.container_limit_mb(), 6000)
            self.assertEqual(memguard.soft_limit_mb(), 4500)
            self.assertEqual(memguard.hard_limit_mb(), 5400)
        with mock.patch.object(memguard, "cgroup_limit_mb", return_value=8192):      # Railway 8 GB
            self.assertEqual(memguard.soft_limit_mb(), 6144)
            self.assertEqual(memguard.hard_limit_mb(), 7372)
        with mock.patch.object(memguard, "cgroup_limit_mb", return_value=1024):
            self.assertEqual(memguard.soft_limit_mb(), 768)
            self.assertEqual(memguard.hard_limit_mb(), 921)
        with mock.patch.dict(os.environ, {"MEMORY_SOFT_LIMIT_MB": "900", "MEMORY_HARD_LIMIT_MB": "1200"}):
            self.assertEqual((memguard.soft_limit_mb(), memguard.hard_limit_mb()), (900, 1200))
        with mock.patch.dict(os.environ, {"MEMORY_SOFT_LIMIT_MB": "900", "MEMORY_HARD_LIMIT_MB": "500"}):
            self.assertEqual(memguard.hard_limit_mb(), 900)                          # not below the soft one

    def test_cgroup_file(self):
        with tempfile.TemporaryDirectory() as d:
            f = os.path.join(d, "memory.max")
            with mock.patch.object(memguard, "CGROUP_FILES", (f,)):
                self.assertIsNone(memguard.cgroup_limit_mb())
                for raw, want in (("8589934592\n", 8192), ("max\n", None)):
                    with open(f, "w") as fh:
                        fh.write(raw)
                    self.assertEqual(memguard.cgroup_limit_mb(), want)

    def limits(self, soft=100, hard=200):
        return mock.patch.dict(os.environ, {"MEMORY_SOFT_LIMIT_MB": str(soft), "MEMORY_HARD_LIMIT_MB": str(hard)})

    def test_below_soft_no_relief(self):
        dropped = []
        with self.limits(), mock.patch.object(memguard, "_droppers", [lambda: dropped.append(1)]), \
                mock.patch.object(memguard, "rss_mb", return_value=50):
            self.assertFalse(memguard.over(live=9, cap=3))
        self.assertEqual(dropped, [])

    def test_relief_helped(self):
        rss = iter([500, 500, 300, 60])        # check, before relief, after gc, after malloc_trim
        with self.limits(), mock.patch.object(memguard, "_droppers", [lambda: None]), \
                mock.patch.object(memguard, "_trim", return_value=True) as trim, \
                mock.patch.object(memguard, "rss_mb", side_effect=lambda: next(rss)):
            self.assertFalse(memguard.over(live=8, cap=3))
        trim.assert_called_once()
        self.assertIn("memory: relieve 500 MB -> caches+gc 300 MB -> malloc_trim 60 MB", self.out.getvalue())
        self.assertEqual(memguard._state["pause"], memguard.RELIEVE_EVERY)

    def test_stuck_memory_soft_band_allows_up_to_cap(self):
        """Relief did not lower memory (prod: 2583 -> 2583): between thresholds scans run up to cap, above the hard one — busy."""
        dropped = []
        with self.limits(), mock.patch.object(memguard, "_droppers", [lambda: dropped.append(1)]), \
                mock.patch.object(memguard, "_trim", return_value=True):
            with mock.patch.object(memguard, "rss_mb", return_value=150):
                self.assertFalse(memguard.over(live=0, cap=3))
                self.assertFalse(memguard.over(live=1, cap=3))
                self.assertFalse(memguard.over(live=2, cap=3))
                self.assertTrue(memguard.over(live=3, cap=3))     # no queue
                self.assertTrue(memguard.over(live=1))            # cap 0 (alerts rechecks) — busy above the soft one
            self.assertEqual(dropped, [1])                         # useless relief — no more often than RELIEVE_IDLE
            self.assertEqual(memguard._state["pause"], memguard.RELIEVE_IDLE)
            with mock.patch.object(memguard, "rss_mb", return_value=250):
                self.assertTrue(memguard.over(live=1, cap=3))
                self.assertFalse(memguard.over(live=0, cap=3))    # with no scans, refusing will not free memory
            memguard._state["relieved"] -= memguard.RELIEVE_IDLE
            with mock.patch.object(memguard, "rss_mb", return_value=150):
                memguard.over(live=1, cap=3)
            self.assertEqual(dropped, [1, 1])
        self.assertEqual(self.out.getvalue().count("memory: relieve"), 2)
        self.assertNotIn("letting the scan start", self.out.getvalue())

    def test_disabled_or_no_proc(self):
        with mock.patch.dict(os.environ, {"MEMORY_SOFT_LIMIT_MB": "0"}), \
                mock.patch.object(memguard, "rss_mb", return_value=10 ** 6):
            self.assertFalse(memguard.over(live=5))
        with mock.patch.object(memguard, "rss_mb", return_value=None):
            self.assertFalse(memguard.over(live=5))

    def test_trim_without_glibc(self):
        with mock.patch.object(memguard, "_libc", []), \
                mock.patch.object(memguard.ctypes, "CDLL", side_effect=OSError("no libc.so.6")):
            self.assertFalse(memguard._trim())
            self.assertFalse(memguard._trim())
        lib = mock.Mock()
        with mock.patch.object(memguard, "_libc", [lib]):
            self.assertTrue(memguard._trim())
        lib.malloc_trim.assert_called_once_with(0)
        with mock.patch.object(memguard, "rss_mb", return_value=None), \
                mock.patch.object(memguard, "_trim", return_value=False):
            memguard.relieve()
        self.assertIn("malloc_trim n/a", self.out.getvalue())

    def test_status_line_and_monitor(self):
        with self.limits(), mock.patch.object(memguard, "rss_mb", return_value=2583.4), \
                mock.patch.object(memguard, "cgroup_limit_mb", return_value=8192):
            self.assertEqual(memguard.status_line(2, ", x"),
                             "memory: rss 2583 MB (soft 100 MB, hard 200 MB, limit 8192 MB), scans active 2, x")
            ticks, stop = threading.Event(), threading.Event()

            def stats():
                ticks.set()
                return 1, ""
            t = memguard.start_monitor(stats, every=0.01, stop=stop)
            self.assertTrue(ticks.wait(2))
            stop.set()
            t.join(2)
            self.assertFalse(t.is_alive())
        with mock.patch.dict(os.environ, {"MEMORY_SOFT_LIMIT_MB": "0"}), \
                mock.patch.object(memguard, "rss_mb", return_value=None):
            self.assertEqual(memguard.status_line(0), "memory: rss ? MB (guard off), scans active 0")

    def test_server_registers_adapter_cache_drop(self):
        self.assertIn(ch.drop_caches, memguard._droppers)


class TestServerBusy(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.httpd = ThreadingHTTPServer(("127.0.0.1", 0), server.H)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def setUp(self):
        with server._lock:
            server.JOBS.clear(); server.BY_TOKEN.clear()
        memguard._state.update(relieved=0.0, pause=memguard.RELIEVE_EVERY)
        self.fakes = fakes.patched()
        self.fakes.__enter__()
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {"DRAW_DB_PATH": os.path.join(self.tmp.name, "t.db"),
                                                "MEMORY_SOFT_LIMIT_MB": "0"})
        self.env.__enter__()

    def tearDown(self):
        for _ in range(200):                     # the test's scans finished while the adapter is patched
            if server._ACTIVE[0] == 0:
                break
            time.sleep(0.05)
        with server._stores_lock:
            for stores in (server._recent_stores, server._rw_stores):
                for st in stores.values():
                    st.close()
                stores.clear()
        self.env.__exit__(None, None, None)
        self.fakes.__exit__(None, None, None)
        self.tmp.cleanup()

    def request(self, path, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, method="POST" if data is not None else "GET",
                                     headers={"content-type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status, json.loads(r.read()), dict(r.headers)
        except urllib.error.HTTPError as e:
            with e:
                return e.code, json.loads(e.read()), dict(e.headers)

    def scan_done(self, token=fakes.TOKEN):
        code, d, _ = self.request("/api/scan", {"token": token})
        self.assertEqual(code, 200)
        for _ in range(200):
            _, r, _ = self.request(f"/api/result?job={d['job']}")
            if r["done"]:
                return d["job"], r
            time.sleep(0.05)
        self.fail("scan did not finish")

    def full(self):
        return mock.patch.object(server, "_ACTIVE", [server.MAX_CONCURRENT + server.SCAN_QUEUE_MAX])

    def test_queue_full_503_busy(self):
        with self.full():
            code, d, h = self.request("/api/scan", {"token": fakes.TOKEN})
        self.assertEqual(code, 503)
        self.assertEqual(d, {"error": "busy", "message": "Scanner is busy, try again in a few seconds"})
        self.assertEqual(h.get("retry-after") or h.get("Retry-After"), "5")
        self.assertEqual(server.BY_TOKEN, {})

    def test_cache_and_join_work_when_full(self):
        jid, r = self.scan_done()
        self.assertIn("result", r)
        with self.full():
            code, d, _ = self.request("/api/scan", {"token": fakes.TOKEN})      # 10-minute cache
            self.assertEqual((code, d), (200, {"job": jid}))
            with server._lock:                                                 # a scan of the same token already running
                server.JOBS["run1"] = {"token": fakes.OTHER, "chain": "robinhood", "events": [], "done": False,
                                       "result": None, "error": None, "ts": time.time()}
                server.BY_TOKEN[fakes.OTHER] = "run1"
            code, d, _ = self.request("/api/scan", {"token": fakes.OTHER})
            self.assertEqual((code, d), (200, {"job": "run1"}))

    def test_active_counter_returns_to_zero(self):
        self.scan_done()
        time.sleep(0.1)
        self.assertEqual(server._ACTIVE[0], 0)

    def test_memory_busy(self):
        env = {"MEMORY_SOFT_LIMIT_MB": "100", "MEMORY_HARD_LIMIT_MB": "200"}
        with mock.patch.dict(os.environ, env), mock.patch.object(memguard, "rss_mb", return_value=900):
            with mock.patch.object(server, "_ACTIVE", [1]):                    # above the hard one
                code, d, _ = self.request("/api/scan", {"token": fakes.TOKEN})
            self.assertEqual((code, d["error"]), (503, "busy"))
            code, _, _ = self.request("/api/scan", {"token": fakes.TOKEN})      # no scans — let it in
            self.assertEqual(code, 200)

    def test_memory_soft_band_up_to_max_concurrent(self):
        env = {"MEMORY_SOFT_LIMIT_MB": "100", "MEMORY_HARD_LIMIT_MB": "200"}
        with mock.patch.dict(os.environ, env), mock.patch.object(memguard, "rss_mb", return_value=150):
            active = [server.MAX_CONCURRENT - 1]
            with mock.patch.object(server, "_ACTIVE", active):
                code, _, _ = self.request("/api/scan", {"token": fakes.TOKEN})
                self.assertEqual(code, 200)
                for _ in range(200):                     # scan finished under the patched counter
                    if active[0] == server.MAX_CONCURRENT - 1:
                        break
                    time.sleep(0.05)
                self.assertEqual(active[0], server.MAX_CONCURRENT - 1)
            with mock.patch.object(server, "_ACTIVE", [server.MAX_CONCURRENT]):
                code, d, _ = self.request("/api/scan", {"token": fakes.OTHER})
                self.assertEqual((code, d["error"]), (503, "busy"))

    def test_scan_stats_per_minute(self):
        server.scan_stats()
        self.scan_done()
        with self.full():
            self.request("/api/scan", {"token": fakes.OTHER})
        active, tail = server.scan_stats()
        self.assertEqual(tail, ", last min: 1 started, 1 busy")
        self.assertEqual(server.scan_stats()[1], ", last min: 0 started, 0 busy")

    def test_rewards_db_failure_is_503_and_scan_lives(self):
        locked = sqlite3.OperationalError("database is locked")
        with mock.patch.dict(os.environ, {"REWARDS_ENABLED": "true"}), \
                mock.patch.object(server, "rewards_store", side_effect=locked):
            code, d, _ = self.request("/api/rewards/status")
            self.assertEqual((code, d), (503, {"error": "temporarily unavailable"}))
            code, _, _ = self.request("/api/rewards/history?kind=burns")
            self.assertEqual(code, 503)
        _, r = self.scan_done()
        self.assertIn("result", r)
        self.assertEqual(self.request("/health")[0], 200)

    def test_recent_db_failure_does_not_break_scan(self):
        with mock.patch.object(server, "recent_store", side_effect=sqlite3.OperationalError("database is locked")):
            _, r = self.scan_done()
            self.assertIn("result", r)
            code, d, _ = self.request("/api/recent")
        self.assertEqual((code, d), (200, {"items": []}))


class TestPollingLoad(TestServerBusy):
    """Page polls do not hit SQLite: statuses and config from process memory, Cache-Control for Cloudflare;
    per-IP limit on new scans (CF-Connecting-IP)."""

    def scan_as(self, token, headers):
        req = urllib.request.Request(self.base + "/api/scan", data=json.dumps({"token": token}).encode(),
                                     method="POST", headers={"content-type": "application/json"} | headers)
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                return r.status, json.loads(r.read()), dict(r.headers)
        except urllib.error.HTTPError as e:
            with e:
                return e.code, json.loads(e.read()), dict(e.headers)

    def test_rewards_status_cached(self):
        import rewards_service as rs
        calls = []
        real = rs.status_json
        with mock.patch.dict(os.environ, {"REWARDS_ENABLED": "true"}), \
                mock.patch.object(rs, "status_json", side_effect=lambda *a, **k: calls.append(1) or real(*a, **k)):
            code, a, h = self.request("/api/rewards/status")
            self.assertEqual(code, 200)
            self.assertEqual(h["cache-control"], "public, max-age=30")
            code, b, _ = self.request("/api/rewards/status")
            self.assertEqual(len(calls), 1)                          # second — from memory, no SQLite
            self.assertEqual({**a, "now": None}, {**b, "now": None})
            self.assertIn("now", b)
            with mock.patch.object(server, "STATUS_TTL", 0):
                self.request("/api/rewards/status")
            self.assertEqual(len(calls), 2)

    def test_status_error_not_cached(self):
        with mock.patch.dict(os.environ, {"REWARDS_ENABLED": "true"}):
            with mock.patch.object(server, "rewards_store", side_effect=sqlite3.OperationalError("database is locked")):
                self.assertEqual(self.request("/api/rewards/status")[0], 503)
            self.assertEqual(self.request("/api/rewards/status")[0], 200)

    def test_draw_status_and_config_cached(self):
        import draw_service as ds
        with mock.patch.object(ds, "status_json", return_value={"enabled": False}) as st:
            for _ in range(3):
                code, d, h = self.request("/api/draw/status")
            self.assertEqual((code, d, h["cache-control"], st.call_count), (200, {"enabled": False}, "public, max-age=30", 1))
        code, _, h = self.request("/api/config")
        self.assertEqual((code, h["cache-control"]), (200, "public, max-age=30"))

    def test_recent_cached_15s(self):
        self.request("/api/recent")
        with mock.patch.object(server, "recent_store", side_effect=AssertionError("SQLite")):
            code, _, h = self.request("/api/recent")
        self.assertEqual((code, h["cache-control"]), (200, "public, max-age=15"))

    def test_scan_rate_limit_per_ip(self):
        ip = {"CF-Connecting-IP": "203.0.113.7"}
        with mock.patch.object(server, "SCAN_RATE_PER_MIN", 2), mock.patch.object(server, "SCAN_QUEUE_MAX", 100):
            for t in (fakes.TOKEN, "0x" + "1" * 40):
                self.assertEqual(self.scan_as(t, ip)[0], 200)
            code, d, h = self.scan_as("0x" + "9" * 40, ip)
            self.assertEqual((code, d), (429, server.RATE_LIMITED))
            self.assertTrue(1 <= int(h["retry-after"]) <= 61)
            self.assertEqual(self.scan_as(fakes.TOKEN, ip)[0], 200)             # running scan or cache — not a new one
            self.assertEqual(self.scan_as("0x" + "9" * 40, {"CF-Connecting-IP": "198.51.100.1"})[0], 200)
            self.assertEqual(self.scan_as("0x" + "8" * 40, ip | {"User-Agent": "crawlscan-bot"})[0], 200)
            with mock.patch.dict(os.environ, {"ALERTS_API_SECRET": "s3cret"}):
                self.assertEqual(self.scan_as("0x" + "7" * 40, ip | {"X-Alerts-Secret": "s3cret"})[0], 200)
                self.assertEqual(self.scan_as("0x" + "6" * 40, ip | {"X-Alerts-Secret": "wrong"})[0], 429)

    def test_rate_window(self):
        with mock.patch.dict(server._RATE, clear=True):
            for t in (0, 1):
                server._rate_take(("a", 2), 100.0 + t)
            with self.assertRaises(server.RateLimited) as cm:
                server._rate_take(("a", 2), 102.0)
            self.assertEqual(cm.exception.args[0], 59)
            server._rate_take(("a", 2), 160.5)                       # the first one left the window
            server._rate_take(None, 160.5)                           # no limit

    def test_scan_client(self):
        with mock.patch.dict(os.environ, {"ALERTS_API_SECRET": "s"}):
            self.assertIsNone(server.scan_client({"X-Alerts-Secret": "s"}, "1.1.1.1"))
            self.assertEqual(server.scan_client({"CF-Connecting-IP": "2.2.2.2"}, "10.0.0.1"),
                             ("2.2.2.2", server.SCAN_RATE_PER_MIN))
            self.assertEqual(server.scan_client({"User-Agent": "crawlscan-bot"}, "10.0.0.1"),
                             ("bot:10.0.0.1", server.SCAN_RATE_BOT_PER_MIN))


class TestRecheckMemory(unittest.TestCase):

    def test_skips_when_memory_high(self):
        tmp = tempfile.TemporaryDirectory()
        st = AlertsStore(os.path.join(tmp.name, "r.db"))
        clock, scanned, logs = tar.Clock(), [], []
        st.watch(1, tar.T1, "robinhood", now=int(clock()))
        high = [True]
        rc = ar.Rechecker(lambda: st, lambda t: scanned.append(t) or tar.result(t), lambda r: None, None,
                          live_count=lambda: 0, clock=clock, sleep=clock.sleep, log=logs.append,
                          cfg={"recheck_min": 15, "max_per_hour": 60}, memory_high=lambda: high[0])
        rc.tick()
        self.assertEqual(scanned, [])
        self.assertIn("alerts: recheck skipped: memory high, 1 waiting", logs)
        high[0] = False
        rc.tick()
        self.assertEqual(scanned, [tar.T1])
        st.close()
        tmp.cleanup()


class TestBotBusy(unittest.TestCase):

    def test_api_503_busy(self):
        body = json.dumps(server.BUSY).encode()
        err = urllib.error.HTTPError("u", 503, "busy", {}, io.BytesIO(body))
        with mock.patch.object(bot_api.urllib.request, "urlopen", side_effect=err):
            with self.assertRaises(bot_api.Busy) as cm:
                bot_api.CrawlScan("https://x.test").scan(RH)
        self.assertEqual(str(cm.exception), server.BUSY["message"])

    def test_scan_sends_secret_and_429_is_busy(self):
        seen = []

        def urlopen(req, timeout=None):
            seen.append(dict(req.header_items()))
            raise urllib.error.HTTPError("u", 429, "rl", {}, io.BytesIO(json.dumps(server.RATE_LIMITED).encode()))

        with mock.patch.object(bot_api.urllib.request, "urlopen", side_effect=urlopen):
            with self.assertRaises(bot_api.Busy):
                bot_api.CrawlScan("https://x.test", alerts_secret="s3").scan(RH)
            with self.assertRaises(bot_api.Busy):
                bot_api.CrawlScan("https://x.test").scan(RH)
        self.assertEqual(seen[0].get("X-alerts-secret"), "s3")
        self.assertNotIn("X-alerts-secret", seen[1])
        self.assertEqual(seen[0].get("User-agent"), "crawlscan-bot")

    def test_bot_shows_busy_text(self):
        class BusyAPI(FakeAPI):
            def scan(self, token):
                raise bot_api.Busy(server.BUSY["message"])

        bot, tg, _ = make(api=BusyAPI())
        bot.handle_update(private(RH))
        drain(bot)
        self.assertEqual(tg.of("editMessageText")[-1]["text"], T.SITE_BUSY)
        self.assertIn("Scanner is busy, try again in a few seconds", T.SITE_BUSY)


class TestFrontendBusy(unittest.TestCase):

    def test_build_handles_busy(self):
        src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "scripts", "build_frontend.py"), encoding="utf-8").read()
        self.assertIn(f"const BUSY_TEXT='{server.BUSY['message']}'", src)
        self.assertIn("d.error==='busy'", src)
        self.assertIn("fail(d.message||d.error||('http '+r.status))", src)   # 429 rate_limited — message text
        self.assertIn("if(!document.hidden&&since>(busy?30000:60000)) this.loadRewards();", src)
        self.assertIn("if(!document.hidden&&((past&&since>60000)||since>300000)) this.loadDraw();", src)
        self.assertIn("if(document.hidden||t-(this._recentAt||0)<20000) return;", src)


if __name__ == "__main__":
    unittest.main()
